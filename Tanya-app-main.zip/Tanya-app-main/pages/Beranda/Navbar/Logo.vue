<template>
    <div class="flex">
            <li>
                <div class="mr-3 pr-3">
                    <a href="#" class="block mt-1 text-white  bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 " aria-current="page">
                        <img src="/image/home linear.png" class="w-7 " alt="">  
                        </a>
                </div>
            </li>

            <li>
                <a href="/survey.html" class="">
                    <div class="group fixed">
                    <img src="/image/article white.png" class="w-9 group-hover:hidden group-hover:border-b-2 group-hover:border-white transition duration-200 ease-in-out" alt="">
                    <img src="/image/artice active.png" class="w-9 inset-0 opacity-0 group-hover:opacity-100 " alt="">
                    </div>
                </a>
            </li>  
    </div>
</template>

<script>
export default {
    name: "Logo"
}

</script>