<template>
    <div>
        <Navbar></Navbar>
        <div class="border-gray-200 bg-gray-700 h-[100rem] text-gray-200">

        </div>
    </div>
</template>

<script>
import Navbar from '../Beranda/Navbar/Navbar.vue';
export default {
    components: {
        Navbar
    },  
    setup () {
        

        return {}
    }
}
</script>

<style >

</style>