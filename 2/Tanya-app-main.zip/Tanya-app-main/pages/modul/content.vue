<script>
import Navbar from '../Beranda/Navbar/Navbar.vue';
export default {
    name: "article",
    components:{
        Navbar
    },
    setup () {
        

        return {}
    }
}
</script>

<template>
    <div>
        <Navbar></Navbar>
        <div class="border-gray-200 bg-gray-700 h-[100rem] text-gray-200">
            
            <div id="article" class="pt-20 mt-4 rounded-lg flex  justify-center  ">
                <div class="flex w-1/2  ">
                    <NuxtLink type="button" to="/modul/esa" class="  text-gray-100 border rounded-lg shadow border-gray-900 bg-gray-900 hover:bg-gray-800">
                        
                        <div class="flex ">
                            <img class="object-cover inline-block w-1/2 rounded-t-lg h-96 md:h-auto md:w-48 md:rounded-none md:rounded-l-lg" src="/image/bg-1.jpg" alt="">
                            <h4 class="container mt-5 ml-5 text-3xl font-bold text-white">Noteworthy technology acquisitions 2021 
                            <p class="my-5 mr-5 text-sm font-normal text-gray-400">Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order. what they do to the palestine were come from this place
                            </p>
                        </h4>
                        </div>
                    </NuxtLink>
                </div>


              </div>
              
              <div  class=" mt-4 rounded-lg flex  justify-center  ">
                  <div class="flex w-1/2  ">
                      <a type="button" href="#" class="  text-gray-100 border rounded-lg shadow border-gray-700 bg-gray-900 hover:bg-gray-800">
                          
                          <div class="flex ">
                              <img class="object-cover inline-block w-1/2 rounded-t-lg h-96 md:h-auto md:w-48 md:rounded-none md:rounded-l-lg" src="/image/bg-1.jpg" alt="">
                              <h4 class="container mt-5 ml-5 text-3xl font-bold text-white">Noteworthy technology acquisitions 2021 
                              <p class="my-5 mr-5 text-sm font-normal text-gray-400">Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order. what they do to the palestine were come from this place
                              </p>
                          </h4>
                          </div>
                      </a>
                  </div>
              </div>
        </div>

          
    </div>
</template>




<style>
</style>
* {
    border: 1px solid blueviolet;
}