<template>
    <div>
        <Profile></Profile>
    </div>
</template>

<script>
import Profile from './profile/Profile.vue'
export default {
    components:{
        Profile
    },
    setup () {
        

        return {}
    }
}
</script>

<style lang="scss" scoped>

</style>