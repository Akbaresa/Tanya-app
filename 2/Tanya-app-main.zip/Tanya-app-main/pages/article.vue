<template>
    <div>
        <Article></Article>
    </div>
</template>

<script>
import Article from './modul/content.vue'
export default {
  components:{
    Article
  },
    setup () {
        

        return {}
    }
}
import('preline')
</script>

<style lang="scss" scoped>

</style>