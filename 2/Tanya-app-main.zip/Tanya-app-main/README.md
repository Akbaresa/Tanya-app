# tata cara push ke repository ini 
# CLONE
### 1. git clone (link repo ini)

# SUDAH CLONE
### 1. git pull main
### 2. ubah code sesuai tugas anda
### 3. git add .
### 3. git commit "pesan anda"
### 4. git push main